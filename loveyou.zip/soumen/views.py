from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def home(request):
    if request.method == 'POST':
        color = request.POST['color']
        txt_color = request.POST['txt_color']
        context = {'col' : color, 'txt_col': txt_color}
        return render(request, 'home.html', context)
    return render(request, 'home.html')
