from django.urls import path
from soumen import views


urlpatterns = [
    path('',views.home,name='home'),
]
